# Western Power Timesheet Application for Power Apps

This package contains all the necessary files to create a Power Apps solution for the Western Power Timesheet Application. The solution includes data schemas, Power Automate flows, and a Canvas App.

## Components

1. **Data Schema Files**:
   - `Projects.json` - Project entity definition
   - `WorkOrders.json` - Work Order entity definition
   - `TimesheetEntries.json` - Timesheet Entry entity definition
   - `ProjectEvents.json` - Project Event entity definition

2. **Power Automate Flows**:
   - `Flow_CreateProject.json` - Flow to create a new project with default work orders
   - `Flow_CreateTimesheetEntry.json` - Flow to create a timesheet entry with time range
   - `Flow_BulkDeleteProjects.json` - Flow to delete multiple projects at once

3. **Power Apps Canvas App**:
   - `WesternPowerTimesheet_Canvas.msapp` - Main Canvas App file

## Import Instructions

### Step 1: Create a Dataverse Database in Power Apps

1. Sign in to [Power Apps](https://make.powerapps.com)
2. Navigate to your environment (or create a new one)
3. Go to "Data" > "Tables"
4. Create new tables based on the schema files in this package

### Step 2: Import Power Automate Flows

1. Sign in to [Power Automate](https://flow.microsoft.com)
2. Navigate to "My flows" > "Import" > "Import from a file"
3. Select the .json flow files from this package
4. Configure the connections when prompted
5. Complete the import process

### Step 3: Import the Canvas App

1. Go back to [Power Apps](https://make.powerapps.com)
2. Navigate to "Apps" > "Import canvas app"
3. Select the `WesternPowerTimesheet_Canvas.msapp` file
4. Configure the connections when prompted
5. Complete the import process

### Step 4: Configure Data Connections

1. Open the imported Canvas App in edit mode
2. Navigate to "Data" in the left sidebar
3. Connect to the Dataverse tables you created in Step 1
4. Connect to the Power Automate flows you imported in Step 2
5. Save and publish the app

## Key Features

1. **Project Management**:
   - Create, view, edit, and delete projects
   - Track project status
   - Manage project notes

2. **Work Orders**:
   - Each project has two default work order types: Validation and Internal Design
   - Work orders are automatically created with the project

3. **Timesheet Entry**:
   - Weekly timesheet view
   - Enter time by day with start and end times
   - Select work order type for each entry
   - Hours are automatically calculated from time range
   - Edit and delete existing entries

4. **Reporting**:
   - Dashboard with summary metrics
   - Visualizations for time allocation
   - Reports by project and work order type

## Customization

Feel free to customize the application to meet your specific needs:

1. Edit the data schema to add additional fields
2. Modify the Power Automate flows to implement custom business logic
3. Enhance the Canvas App with additional screens and functionality

## Support

For questions or issues, please contact your system administrator or the IT support team.

---

© 2025 Western Power